package fr.ensta.lerouxlu;

import enstabretagne.base.time.LogicalDateTime;

public interface ISimulationDateProvider {

	LogicalDateTime simulationDate();
	
}
