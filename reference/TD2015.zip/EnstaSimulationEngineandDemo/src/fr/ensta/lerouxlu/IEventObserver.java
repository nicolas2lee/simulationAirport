package fr.ensta.lerouxlu;

public interface IEventObserver {

	void onEventPosted(ISimEvent event);
	
}
