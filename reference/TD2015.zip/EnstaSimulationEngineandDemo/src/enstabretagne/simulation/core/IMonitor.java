/**
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.simulation.core;

import java.time.temporal.Temporal;


public interface IMonitor {

}

