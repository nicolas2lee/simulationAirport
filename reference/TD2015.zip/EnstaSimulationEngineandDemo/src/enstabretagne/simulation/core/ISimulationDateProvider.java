/**
* Classe ISimulationDateProvider.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.simulation.core;

import enstabretagne.base.time.LogicalDateTime;

public interface ISimulationDateProvider {

	LogicalDateTime SimulationDate();

}

