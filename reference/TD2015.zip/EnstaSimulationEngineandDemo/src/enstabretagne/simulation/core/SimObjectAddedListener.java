/**
* Classe SimObjectAddedListener.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.simulation.core;

@FunctionalInterface
public interface SimObjectAddedListener {
	void SimObjectAdded(SimObject obj);
}


