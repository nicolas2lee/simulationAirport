package enstabretagne.simulation.components;

public interface IScenarioIdProvider {
	ScenarioId getScenarioId();
}
