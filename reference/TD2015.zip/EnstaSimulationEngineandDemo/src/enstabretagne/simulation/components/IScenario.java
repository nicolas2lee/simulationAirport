/**
* Classe IScenario.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.simulation.components;

public interface IScenario {
	
}

