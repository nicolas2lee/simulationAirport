/**
* Classe IPendule.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.travaux_diriges.TD_corrige.Pendule.SimEntity.GL3DRepresentations;

import enstabretagne.monitors.IMovable;

public interface IPendule extends IMovable {

	double getRadius();

}

