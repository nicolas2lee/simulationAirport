/**
* Classe OceanInit.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.travaux_diriges.TD_corrige.SailBoat.SimEntity.Ocean;

import enstabretagne.simulation.components.SimInitParameters;

public class OceanInit extends SimInitParameters{

	public static final OceanInit basicOcean = new OceanInit();
	
}

