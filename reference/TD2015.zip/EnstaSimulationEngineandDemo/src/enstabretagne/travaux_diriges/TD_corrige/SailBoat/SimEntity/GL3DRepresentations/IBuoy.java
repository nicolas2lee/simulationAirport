/**
* Classe IBuoy.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.travaux_diriges.TD_corrige.SailBoat.SimEntity.GL3DRepresentations;

import enstabretagne.monitors.IMovable;

public interface IBuoy extends IMovable{

}

