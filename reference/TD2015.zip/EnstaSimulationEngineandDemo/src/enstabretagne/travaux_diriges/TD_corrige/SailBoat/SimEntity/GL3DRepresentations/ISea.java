/**
* Classe ISea.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.travaux_diriges.TD_corrige.SailBoat.SimEntity.GL3DRepresentations;

public interface ISea {

}

