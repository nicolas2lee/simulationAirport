/**
* Classe Messages.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.travaux_diriges.TD_corrige.SalonDeCoiffure.base.messages;

public class Messages {
	public static final String DateConversionError = "Erreur de conversion du format de l'heure qui doit �tre d�crite selon le sch�ma HH:mm."; 
	public static final String OuverturePeriodeNouveauxClients = "D�but d'arriv�e de nouveaux clients"; 
	public static final String NouveauClientPotentiel = "Un nouveau Client potentiel arrive : %s"; 
	public static final String FinPeriodeNouveauxClients = "Fin d'arriv�e de nouveaux clients";
	public static final String OuvertureSalon = "Salon Ouvert";
	public static final String FermetureSalon = "Salon Ferm�";
	public static final String FinDeCoupeDeCheveux = "Fin de coupe pour : %s";
	public static final String QuitterSalonCheuveuxCoupes = " quitte le salon les cheuveux coup�s";
	public static final String QuitterSalonCheuveuxNonCoupes = " quitte le salon les cheuveux non coup�s";
}

