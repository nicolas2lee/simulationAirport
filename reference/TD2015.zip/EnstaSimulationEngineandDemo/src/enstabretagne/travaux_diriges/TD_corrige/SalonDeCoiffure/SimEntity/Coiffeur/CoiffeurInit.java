/**
* Classe CoiffeurInit.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.travaux_diriges.TD_corrige.SalonDeCoiffure.SimEntity.Coiffeur;

import enstabretagne.simulation.components.SimInitParameters;

public class CoiffeurInit extends SimInitParameters {

}

