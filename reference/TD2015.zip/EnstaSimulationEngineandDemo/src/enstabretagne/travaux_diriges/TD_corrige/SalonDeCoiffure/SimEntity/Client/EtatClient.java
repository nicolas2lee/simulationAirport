/**
* Classe EtatClient.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.travaux_diriges.TD_corrige.SalonDeCoiffure.SimEntity.Client;

public enum EtatClient {

	RechercheSalon("Recherche Salon"),
	AttenteCoiffeur("Attente du coiffeur"),
	CheuveuxEnCoursDeCoupe("Cheuveux en cours de Coupe"),
	CheuveuxCoupes("Cheuveux Coup�s"),
	PartiCheuveuxCoupes("Parti cheveux coup�s"),
	PartiCheuveuxNonCoupes("Parti cheveux non coup�s");
	
	private String etatClient;
	private EtatClient(String etat){
		etatClient=etat;
	}
	
	@Override
	public String toString() {
		return etatClient;
	}
}

