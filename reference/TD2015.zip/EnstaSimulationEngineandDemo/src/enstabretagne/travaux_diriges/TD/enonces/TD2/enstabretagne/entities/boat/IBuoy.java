/**
* Classe IBuoy.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.entities.boat;

import enstabretagne.entities.IMovable;

public interface IBuoy extends IMovable{

}

