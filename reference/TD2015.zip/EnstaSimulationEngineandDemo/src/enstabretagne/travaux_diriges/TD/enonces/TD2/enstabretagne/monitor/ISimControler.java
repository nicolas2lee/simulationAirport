/**
* Classe ISimControler.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.monitor;

public interface ISimControler {

}

