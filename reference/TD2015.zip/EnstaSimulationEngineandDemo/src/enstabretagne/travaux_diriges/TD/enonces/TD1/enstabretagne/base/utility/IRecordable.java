/**
* Classe IRecordable.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.base.utility;

import java.util.List;

public interface IRecordable {
	String[] getTitles();
	String[] getRecords();
	String getClassement();
}

