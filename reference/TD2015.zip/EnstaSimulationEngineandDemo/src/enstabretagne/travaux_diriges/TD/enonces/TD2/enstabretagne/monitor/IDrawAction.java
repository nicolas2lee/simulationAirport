/**
* Classe IDrawAction.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.monitor;

import javax.media.opengl.GL2;

public interface IDrawAction {
	void draw(GL2 gl,Object obj);
}

