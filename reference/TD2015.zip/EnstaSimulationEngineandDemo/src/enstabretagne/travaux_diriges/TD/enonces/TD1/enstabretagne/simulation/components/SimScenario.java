package enstabretagne.simulation.components;

public class SimScenario {

}
