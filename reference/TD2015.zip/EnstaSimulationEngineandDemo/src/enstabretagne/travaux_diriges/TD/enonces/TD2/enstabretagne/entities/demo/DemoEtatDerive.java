/**
* Classe DemoEtatDerive.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.entities.demo;

import enstabretagne.simulation.core.IEtatDerive;

public class DemoEtatDerive implements IEtatDerive{
	
	double taux_z;
	double taux_vz;

	public DemoEtatDerive() {
	}

}

