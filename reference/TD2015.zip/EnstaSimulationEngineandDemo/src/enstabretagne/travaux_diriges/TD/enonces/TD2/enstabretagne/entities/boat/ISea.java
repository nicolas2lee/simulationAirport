/**
* Classe ISea.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.entities.boat;

public interface ISea {

}

