package enstabretagne.simulation.core;

public class SimObject {

}
