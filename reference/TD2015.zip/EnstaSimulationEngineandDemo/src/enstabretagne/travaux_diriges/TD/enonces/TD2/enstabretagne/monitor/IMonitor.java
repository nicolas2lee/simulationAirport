/**
* Classe IMonitor.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.monitor;

import java.time.temporal.Temporal;


public interface IMonitor {

	Temporal InitialCalendarDate();

}

