/**
* Classe IEtatDerive.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.simulation.core;

public interface IEtatDerive {

}

