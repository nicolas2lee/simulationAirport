/**
* Classe ListenerList.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.base.utility;

import java.util.ArrayList;

public class ListenerList<C> extends ArrayList<C> implements IListenerList<C>{

}

