/**
* Classe PortableRandom.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.base.math;

import java.util.Random;

public class PortableRandom extends Random {
	public PortableRandom(int seed) {
		
	}
}

