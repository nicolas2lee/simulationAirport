/**
* Classe MessagesDictionnary.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.base.messages;

public class MessagesDictionnary {

	public static final String NewClassObjectAdded = "Nouvelle classe d'objet ajout�e : %s";
	public static final String NewObjectAdded = "Nouvel Objet ajout� : %s";
	public static final String ObjectTypeNotReferenced = "Type d'objet non r�f�renc� dans le dictionnaire : %s";
	
}

