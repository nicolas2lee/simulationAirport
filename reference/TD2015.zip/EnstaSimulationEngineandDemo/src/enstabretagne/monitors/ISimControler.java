/**
* Classe ISimControler.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.monitors;

public interface ISimControler {

}

